import React, { Component } from 'react';
import StackChart1 from './stackchart1';

class GraphPage extends Component {
    render() {
        return (
            <div className='non-carousel-pages'>
                <StackChart1/>
            </div>
        );
    }
}

export default GraphPage;